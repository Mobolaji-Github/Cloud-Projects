def my_handler(event, context):
            message = 'Hello Lambda World!'
            return message